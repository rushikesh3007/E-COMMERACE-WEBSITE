<?php
$con = new mysqli("localhost", "root", "", "techtreasures",3306);
if (!$con) {
    echo "fail";
    die(mysqli_error($con));
}
?>